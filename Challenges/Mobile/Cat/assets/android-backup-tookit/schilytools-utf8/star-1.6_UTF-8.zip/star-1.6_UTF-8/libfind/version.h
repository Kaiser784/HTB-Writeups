/* @(#)version.h	1.3 19/01/08 Copyright 2018-2019 J. Schilling */

/*
 * The version for libfind/sfind
 */
#define	VERSION		"1.7"
#define	VERSION_NUM	0x10007
#define	VERSION_DATE	"2019/01/08"
