__LINE__ on line 1
#line __LINE__ "line_macro_redef.c"
__LINE__, __FILE__ on line 3
__LINE__, __FILE__ on line 4
