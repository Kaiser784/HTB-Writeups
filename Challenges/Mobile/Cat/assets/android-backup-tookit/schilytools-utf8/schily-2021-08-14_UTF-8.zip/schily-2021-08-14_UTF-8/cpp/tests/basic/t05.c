#define	BLA 1

#if /*


*/ BLA
bla
#endif
