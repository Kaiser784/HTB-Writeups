/*
 * If the 0xFE handling is broken, the replacement will be empty
 */
#define	bla	þ

bla
