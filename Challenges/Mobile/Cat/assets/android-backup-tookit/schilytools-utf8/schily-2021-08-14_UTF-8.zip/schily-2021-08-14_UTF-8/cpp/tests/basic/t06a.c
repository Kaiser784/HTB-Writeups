#define	conc(a,b)a/**/b

conc(./bin/,a)
