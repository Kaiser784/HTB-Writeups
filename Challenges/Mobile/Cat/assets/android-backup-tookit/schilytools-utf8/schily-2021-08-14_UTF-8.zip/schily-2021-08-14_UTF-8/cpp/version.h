/* @(#)version.h	1.4 21/05/29 Copyright 2018-2019 J. Schilling */

/*
 * The version for cpp
 */
#define	VERSION		"2.3"
#define	VERSION_DATE	"2021/05/29"
