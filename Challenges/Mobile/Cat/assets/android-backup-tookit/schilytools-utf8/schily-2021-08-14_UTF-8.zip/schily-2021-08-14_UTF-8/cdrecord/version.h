/* @(#)version.h	1.104 21/07/23 Copyright 2007-20120 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION		"3.02a10"
#define	VERSION_DATE	"2021/07/23"
