/*
 * If the 0xFE handling is broken, __cerror will be replaced by ctl-A
 */
#define	ENTRY(x)	x

ENTRY(__cerror)

#define	NAME		þ

ENTRY(NAME)
