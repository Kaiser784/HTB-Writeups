/* @(#)version.h	1.2 19/01/08 Copyright 2018-2019 J. Schilling */

/*
 * The version for calltree
 */
#define	VERSION		"2.6"
#define	VERSION_DATE	"2019/01/08"
