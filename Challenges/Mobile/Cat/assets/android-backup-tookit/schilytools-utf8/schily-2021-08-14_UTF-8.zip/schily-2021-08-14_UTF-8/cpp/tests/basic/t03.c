__LINE__ on line 1
#line 5 "line_macro_redef.c"
__LINE__, __FILE__ on line 3
__LINE__, __FILE__ on line 4
