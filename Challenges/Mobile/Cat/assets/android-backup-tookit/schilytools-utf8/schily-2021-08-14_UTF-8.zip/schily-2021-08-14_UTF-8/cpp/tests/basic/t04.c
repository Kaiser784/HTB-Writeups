   #if 1
bla
   #endif

