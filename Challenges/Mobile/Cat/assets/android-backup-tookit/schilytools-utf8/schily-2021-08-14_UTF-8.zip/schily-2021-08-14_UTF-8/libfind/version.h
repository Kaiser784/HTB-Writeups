/* @(#)version.h	1.5 21/07/23 Copyright 2018-2020 J. Schilling */

/*
 * The version for libfind/sfind
 */
#define	VERSION		"1.8"
#define	VERSION_NUM	0x1008
#define	VERSION_DATE	"2021/07/23"
