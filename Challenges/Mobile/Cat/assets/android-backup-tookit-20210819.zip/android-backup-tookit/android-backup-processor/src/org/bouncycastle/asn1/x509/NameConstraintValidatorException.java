package org.bouncycastle.asn1.x509;

public class NameConstraintValidatorException
    extends Exception
{
    public NameConstraintValidatorException(String msg)
    {
        super(msg);
    }
}
